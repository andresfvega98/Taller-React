
import './App.css';

import VistaCompleta from './components/vista/VistaCompleta';

function App() {
  return (
  <>
      
    <VistaCompleta />
  </>
  );
}

export default App;
